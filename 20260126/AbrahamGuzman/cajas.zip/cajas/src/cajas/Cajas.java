/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cajas;

import java.util.Random;

/**
 *
 * @author agu3018
 */
public class Cajas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       int [] cajas = {100, 0, 100, 100, 0};
       
       int premio = ofertaBanca(cajas);
        System.out.println(premio);
        
    }
    
    public int[]sortearCajas(int [] premiosOrdenados ){
        Random rd = new Random();
        int [] premiosAleatorios = new int[20];
        for (int i = 0; i < premiosOrdenados.length; i++) {
            int premiosOrdenado = premiosOrdenados[i];
            
        }
    return premiosAleatorios;
    }
    
    public static  int ofertaBanca (int[]Cajas){
       int Premios = 0;
       int posicionValida = 0;
        
        for (int i = 0; i < Cajas.length; i++) {
            if(Cajas[i] != 0){
                posicionValida++;
                Premios += Cajas[i];
            }
            
           
            }
      
        
        
        return  Premios / posicionValida;
        
    }
    
    
}

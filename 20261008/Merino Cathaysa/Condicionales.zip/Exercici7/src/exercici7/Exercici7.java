/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercici7;

import java.util.Scanner;

/**
 *
 * @author cme4538
 */
public class Exercici7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        //7. Programa que llegeix tres números diferents 
        //i ens diu quin és el més gran.
        
        Scanner sc = new Scanner(System.in);
        
        int num1, num2, num3;
        
        System.out.println("Dime 3 números y te diré cuál es mayor. Dime el primero");
        num1 = sc.nextInt();
        
        System.out.println("sime el segundo:");
        num2 = sc.nextInt();
        
        System.out.println("Y dime el tercero:");
        num3 =sc.nextInt();
        
        if (num1 > num2 && num1 > num3) {
            System.out.println("El número más grande es " + num1);
        } else if (num2 > num1 && num2 > num3) {
            System.out.println("El número más grande es " + num2);
        } else{
            System.out.println("El número más grande es " + num3);
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciolibre1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author matia
 */
public class EjercicioLibre1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String regalo;
        int any;
        
        System.out.println("Introduce tu año de nacimiento");
        any = sc.nextInt();
        
        if (any >= 1995 && any <= 2000) {
            regalo = "Teclado";
        }
        else if (any > 2000 && any <= 2005) {
            regalo = "Raton";
        }
        else if (any > 2005 && any <= 2010) {
            regalo = "Ordenador";
        }
        else if (any > 2010 && any <= 2015) {
            regalo = "Altavoces";
        }
        else 
        {
            regalo = "Gorra";
        }
        System.out.println("Has recibido tu regalo, " + regalo + " ,por haber nacido en el año " + any);
    }
    
}
